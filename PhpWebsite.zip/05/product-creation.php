<?php 
include ('dbconnect.php');
include ('header.php');

$error = ['name_error'=>'', 'price_error'=>'', 'color_error'=>''];

if ( isset ( $_POST ['create_product'] ) ) {

    $name           = ($_POST['product_name']);
    $price          = ($_POST['product_price']);
    $color          = ($_POST['product_color']); 
    $description    = ($_POST['description']);

if ( $name == NULL ){
    $error ['name_error'] = "Please Enter Product Name";
}

if ( $price == NULL ){
    $error ['price_error'] = "Please Enter Product Price";
}
    
if ( $color == NULL ){
    $error ['color_error'] = "Please Enter Product Color";
}
    
if ( !array_filter ( $error ) ) {

    $insert = "INSERT INTO `products` (product_name,price,colors,descriptions) VALUES('$name','$price','$color','$description')" ;
        
    if (mysqli_query ($db, $insert)) {
        $success = "Product Successfully Added. You will be Redirected to Products Page.";
        echo "<script type='text/javascript'>alert('$success');</script>";
        header( "refresh:0;url=products.php" );
    }
    
    else {
        $fail = "Product Creation Failed";
        echo "<script type='text/javascript'>alert('$fail');</script>";
        header("refresh:0;url= product-creation.php"); 
        }
     
    }
    
}

?>
   
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <div class="col-md-3"></div>

                <div class="col-md-6" style="color: white; display:block; margin: 0 auto; background: navy; padding: 20px; box-shadow: 10px 10px #0040852e;">

                    <h1 class="text-center"><u><i>Create a Product</i></u></h1>
                    <form action="product-creation.php" method="POST">

                        <div class="form-group">
                            <label for="product_name">Product Name</label>
                            <input type="text" name="product_name" id="product_name" class="form-control" value="<?=$name ?? "" ?>">    
                            <span style="color:red;"> <?= $error['name_error'] ?> </span>
                        </div>

                        <div class="form-group">
                            <label for="product_price">Product Price</label>
                            <input type="text" name="product_price" id="product_price" class="form-control" value="<?=$price ?? "" ?>">
                            <span style="color:red;"> <?= $error['price_error'] ?> </span>
                        </div>
                        
                        <div class="form-group">
                            <label for="product_color">Product Color</label>
                            <input type="text" name="product_color" id="product_color" class="form-control" value="<?=$color ?? "" ?>">
                            <span style="color:red;"> <?= $error['color_error'] ?> </span>
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" id="description" rows="6" class="form-control">
                            <?=$description ?? "" ?>
                            </textarea>
                        </div>

                        <div class="form-group text-center">
                            <input type="submit" name="create_product" value="Create a Product" class="btn btn-primary">
                        </div>

                    </form>

                </div>

                <div class="col-md-3"></div>

            </div>
        </div>
    </div>

<br>

<?php include ('footer.php') ?>