<?php

$host       = 'localhost';
$user       = 'root';
$password   = '';
$database   = 'phpwebsite';

$db = mysqli_connect ( $host, $user, $password, $database );

if ( !$db ) {
    echo "Connect" . mysqli_connect_error();
}

$sql = "SELECT * FROM `products`";

$result = mysqli_query ( $db, $sql );

$data = mysqli_fetch_all ( $result, MYSQLI_ASSOC );

?>