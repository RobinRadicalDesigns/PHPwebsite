<?php include ('header.php') ?>

<?php include ('home.php') ?>

<?php include ('footer.php') ?>