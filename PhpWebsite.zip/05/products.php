<?php 
include ('dbconnect.php');
include ('header.php');
?>

<div class="products">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <div class="container">
                    <div class="row">

                        <?php if  ( !empty ( $data ) ) : ?>
                        <?php foreach ( $data as $product ) : ?>

                        <div class="col-md-4">
                            <div class="card" style="background: navy; color: white; box-shadow: 10px 10px #0040852e; margin-bottom: 30px;">
                                <div class="card-body">
                                    <h5 class="card-title text-center" style="background: #007bff; padding: 10px;">
                                        <?=$product['product_name']; ?>
                                    </h5>
                                    <p class="card-text">
                                        <?=$product['descriptions']; ?>
                                    </p>
                                    
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <p style="padding:10px;">Available Colors - </p>
                                            </div>
                                            <div class="col-md-6">
                                                <?php foreach ( explode ( ',', $product['colors']) as $color) : ?>
                                                <p style="display: list-item;"><?= $color;?> </p>
                                                <?php endforeach ?>
                                            </div>
                                        </div>
                                    </div>

                                    <a class="btn btn-primary" href="#" style="float:left">Details</a>
                                    <b>
                                        <p class="card-text" style="float:right;background: white; padding: 7px; color: red; border-radius: 50px;"> Price -
                                            <?= $product['price']; ?> Tk
                                        </p>
                                    </b>
                                </div>
                            </div>
                        </div>

                        <?php endforeach ?>
                        <?php endif ?>

                    </div>
                </div>



            </div>
        </div>
    </div>
</div>


<br>

<a href="product-creation.php"> <input type="submit" name="product_creation" value="Create a Product" class="btn btn-primary center"></a>

<?php include ('footer.php') ?>