<?php

$host       = 'localhost';
$user       = 'robin2k1_php';
$password   = '123456';
$database   = 'robin2k1_php';

$db = mysqli_connect ( $host, $user, $password, $database );

if ( !$db ) {
    echo "Connect" . mysqli_connect_error();
}

$sql = "SELECT * FROM `products`";

$result = mysqli_query ( $db, $sql );

$data = mysqli_fetch_all ( $result, MYSQLI_ASSOC );

// Free Memory
mysqli_free_result ( $result );

// Connection
mysqli_close ( $db );

?>