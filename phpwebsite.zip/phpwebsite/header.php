<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Radical Designs</title>
    <link rel="shortcut icon" href="RD.png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="navbar" style="background:navy;">
    <div class="container center">
        <div class="row">
            <div class="col-md-12">
            
            <nav class="navbar sticky-top navbar-expand-lg navbar-light bg-light" style="background: navy !important;">
  <a class="navbar-brand" href="index.php"><img src="rd2.png" style="width:150px;" alt=""></a>
  <button class="navbar-toggler" type="button" style="border-color:white !important;" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      
       <li class="nav-item">
        <a class="nav-link" style="color:white; font-size:22px;" href="index.php">Home</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" style="color:white; font-size:22px;" href="products.php">Products</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" style="color:white; font-size:22px;" href="product-creation.php">Product Creation</a>
      </li>
      
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
     
      
       </div>
        </div>
    </div>
</div>

<br>