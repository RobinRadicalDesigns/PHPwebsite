<?php include ('dbconnect.php') ?>

<?php include ('header.php') ?>

<div class="products">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <div class="container">
                    <div class="row">

                        <?php if  ( !empty ( $data ) ) : ?>
                                <?php foreach ( $data as $product ) : ?>

                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <?=$product['product_name']; ?>
                                    </h5>
                                    <p class="card-text">
                                        <?=$product['descriptions']; ?>
                                    </p>
                                    
                                    <?php foreach ( explode ( ',', $product['colors']) as $color) : ?> 
                                    <p><?= $color;?> </p> 
                                    <?php endforeach ?>
    
                                    <a class="btn btn-primary" href="#" style="float:left">Details</a>
                                    <p class="card-text" style="float:right"> Price -
                                        <?= $product['price']; ?> Tk
                                    </p>
                                </div>
                            </div>
                        </div>

                        <?php endforeach ?>
                            <?php endif ?>

                    </div>
                </div>

                

            </div>
        </div>
    </div>
</div>


<br>

<a href="product-creation.php"> <input type="submit" name="product_creation" value="Create a Product" class="btn btn-primary center"></a>

<?php include ('footer.php') ?>