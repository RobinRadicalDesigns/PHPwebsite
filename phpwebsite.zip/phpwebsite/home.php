<div class="home-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center">Welcome to Radical Designs</h1>
<br>
<p style="text-align:justify; font-size:22px; line-height:40px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum sit accusantium eligendi vel provident, tempora animi dolorum, perferendis odio temporibus ipsam vitae praesentium fugiat voluptatum harum. Et eum quod minima. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum sit accusantium eligendi vel provident, tempora animi dolorum, perferendis odio temporibus ipsam vitae praesentium fugiat voluptatum harum. Et eum quod minima.
          <br>
          <br>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae labore voluptate ipsum maiores in odio, facere ullam culpa eius cum fuga adipisci iusto optio magnam voluptatem, quibusdam consequuntur veritatis harum.</p>
           
           <br>
           
        <a href="products.php"> <input type="submit" name="product_page" value="Goto Product Page" class="btn btn-primary center"></a>
           
            </div>
        </div>
    </div>
</div>